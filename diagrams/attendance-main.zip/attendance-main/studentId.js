const User = require('./User');

const ID_PREFIX = 'STU';
const PAD_LENGTH = 3;

function formatStudentId(number) {
    const numeric = parseInt(number, 10);
    const safeNumber = Number.isNaN(numeric) ? 1 : numeric;
    return `${ID_PREFIX}${String(safeNumber).padStart(PAD_LENGTH, '0')}`;
}

function extractNumericSuffix(idValue) {
    if (!idValue) return 0;
    const match = idValue.toString().match(/(\d+)$/);
    return match ? parseInt(match[1], 10) || 0 : 0;
}

async function fetchMaxStudentNumber() {
    const docs = await User.find({ role: 'student' })
        .select('studentId userId')
        .lean();

    let maxNum = 0;
    docs.forEach((doc) => {
        maxNum = Math.max(
            maxNum,
            extractNumericSuffix(doc.studentId),
            extractNumericSuffix(doc.userId)
        );
    });

    return maxNum;
}

async function generateUniqueStudentId() {
    let nextNum = (await fetchMaxStudentNumber()) + 1;
    if (nextNum < 1) nextNum = 1;

    // Try a handful of times in case of races; fall back to timestamp-based value.
    for (let attempt = 0; attempt < 7; attempt++) {
        const candidate = formatStudentId(nextNum);
        const exists = await User.exists({
            $or: [{ studentId: candidate }, { userId: candidate }]
        });

        if (!exists) {
            return { studentId: candidate, numeric: nextNum };
        }
        nextNum += 1;
    }

    const fallback = formatStudentId(Date.now());
    return { studentId: fallback, numeric: extractNumericSuffix(fallback) };
}

module.exports = {
    formatStudentId,
    extractNumericSuffix,
    fetchMaxStudentNumber,
    generateUniqueStudentId
};
