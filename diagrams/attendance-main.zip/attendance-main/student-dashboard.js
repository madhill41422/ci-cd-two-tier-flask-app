const API_URL = 'http://localhost:3000/api';
let studentData = {
    userId: null,
    student: null,
    attendance: [],
    threshold: 85
};

// ==================== INITIALIZATION ====================

document.addEventListener('DOMContentLoaded', () => {
    initializeStudent();
});

function initializeStudent() {
    const userId = localStorage.getItem('userId');
    const userRole = localStorage.getItem('userRole');

    if (userRole !== 'student') {
        window.location.href = 'index.html';
        return;
    }

    studentData.userId = userId;
    loadStudentDashboard();
    setupEventListeners();
}

// ==================== LOAD DASHBOARD DATA ====================

async function loadStudentDashboard() {
    try {
        // Load student info
        const response = await fetch(`${API_URL}/student/dashboard/${studentData.userId}`);
        const data = await response.json();

        if (data.success) {
            studentData.student = data.student;
            displayStudentInfo(data.student);
            updateProgressCircle(data.student.attendancePercentage);
            checkAttendanceAlert(data.student.attendancePercentage);
        }

        // Load attendance history
        const historyResponse = await fetch(`${API_URL}/student/attendance/${studentData.userId}`);
        const historyData = await historyResponse.json();

        if (historyData.success) {
            studentData.attendance = historyData.records;
            displayAttendanceHistory(historyData.records);
            setupChart(historyData.records);
        }
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

// ==================== DISPLAY FUNCTIONS ====================

function displayStudentInfo(student) {
    document.getElementById('userName').textContent = student.name;
    document.getElementById('firstName').textContent = student.name.split(' ')[0];
    document.getElementById('userId').textContent = 'ID: ' + student.userId;
    document.getElementById('attendancePercentage').textContent = student.attendancePercentage;
    document.getElementById('presentDays').textContent = student.presentDays;
    document.getElementById('absentDays').textContent = student.absentDays;
    document.getElementById('totalDays').textContent = student.totalDays;
    document.getElementById('className').textContent = student.className || 'Not Assigned';
    document.getElementById('userEmail').textContent = student.email || '-';
    document.getElementById('userPhone').textContent = student.phone || '-';
}

function updateProgressCircle(percentage) {
    const circumference = 2 * Math.PI * 45; // radius=45
    const offset = circumference - (percentage / 100) * circumference;
    
    const circle = document.querySelector('.progress-fill');
    if (circle) {
        circle.style.strokeDashoffset = offset;
        
        // Change color based on percentage
        if (percentage >= 85) {
            circle.style.stroke = '#27ae60';
        } else if (percentage >= 75) {
            circle.style.stroke = '#f39c12';
        } else {
            circle.style.stroke = '#e74c3c';
        }
    }
}

function checkAttendanceAlert(percentage) {
    const alertSection = document.getElementById('alertSection');
    if (percentage < 85) {
        alertSection.style.display = 'block';
    } else {
        alertSection.style.display = 'none';
    }
}

function displayAttendanceHistory(records) {
    const container = document.getElementById('historyContainer');
    
    if (records.length === 0) {
        container.innerHTML = '<p class="no-records">No attendance records found</p>';
        return;
    }

    // Group by date
    const grouped = {};
    records.forEach(record => {
        const date = new Date(record.date).toLocaleDateString('en-IN');
        if (!grouped[date]) grouped[date] = [];
        grouped[date].push(record);
    });

    container.innerHTML = '';

    // Display most recent records (limit to last 30 days)
    Object.entries(grouped).slice(0, 30).forEach(([date, items]) => {
        const item = items[0]; // Usually one per date
        const status = item.status === 'present' ? 'present' : 'absent';
        const icon = status === 'present' ? 'fa-check-circle' : 'fa-times-circle';
        const label = status === 'present' ? 'Present' : 'Absent';

        const record = document.createElement('div');
        record.className = `history-item history-${status}`;
        record.innerHTML = `
            <div class="history-date">${date}</div>
            <div class="history-status">
                <i class="fas ${icon}"></i> ${label}
            </div>
        `;
        container.appendChild(record);
    });
}

// ==================== FILTERING ====================

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('monthFilter')?.addEventListener('change', filterByMonth);
});

function filterByMonth(e) {
    const selectedMonth = e.target.value;
    
    if (!selectedMonth) {
        displayAttendanceHistory(studentData.attendance);
        return;
    }

    const filtered = studentData.attendance.filter(record => {
        const recordDate = new Date(record.date);
        return recordDate.getMonth() === parseInt(selectedMonth);
    });

    displayAttendanceHistory(filtered);
}

// ==================== CHARTS ====================

function setupChart(records) {
    const ctx = document.getElementById('attendanceChart');
    if (!ctx) return;

    // Group by month
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const presentData = new Array(12).fill(0);
    const absentData = new Array(12).fill(0);

    records.forEach(record => {
        const date = new Date(record.date);
        const month = date.getMonth();
        
        if (record.status === 'present') {
            presentData[month]++;
        } else {
            absentData[month]++;
        }
    });

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: months,
            datasets: [
                {
                    label: 'Present',
                    data: presentData,
                    backgroundColor: '#27ae60',
                    borderRadius: 4
                },
                {
                    label: 'Absent',
                    data: absentData,
                    backgroundColor: '#e74c3c',
                    borderRadius: 4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            scales: {
                y: { beginAtZero: true },
                x: { stacked: false }
            },
            plugins: {
                legend: { position: 'top' }
            }
        }
    });
}

// ==================== EVENT LISTENERS ====================

function setupEventListeners() {
    document.getElementById('logoutBtn')?.addEventListener('click', logout);
}

function logout() {
    localStorage.clear();
    window.location.href = 'index.html';
}
