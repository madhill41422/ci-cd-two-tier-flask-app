require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const connectDB = require('./db');
const User = require('./User');
const Class = require('./Class');
const Attendance = require('./Attendance');
const { importStudentsFromExcel, bootstrapFromExcelIfEmpty, ensureBaseClasses } = require('./excelImport');
const { generateUniqueStudentId, fetchMaxStudentNumber, extractNumericSuffix, formatStudentId } = require('./studentId');

const app = express();
const PORT = 3000;

const DEFAULT_ADMIN_USER_ID = process.env.DEFAULT_ADMIN_USER_ID || '12300';
const DEFAULT_ADMIN_PASSWORD = process.env.DEFAULT_ADMIN_PASSWORD || '123';
const DEFAULT_ADMIN_EMAIL = process.env.DEFAULT_ADMIN_EMAIL || 'admin@school.com';
const DEFAULT_STUDENT_PASSWORD = process.env.DEFAULT_STUDENT_PASSWORD || 'studentPassword123';

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

// Database Connection
connectDB();

// Middleware to check if MongoDB is connected
const checkDBConnection = (req, res, next) => {
    if (mongoose.connection.readyState !== 1) {
        return res.status(503).json({
            success: false,
            message: "Database is connecting. Please wait and try again in a few seconds.",
            readyState: mongoose.connection.readyState
        });
    }
    next();
};

// Bootstrap data from Excel on first successful connection
mongoose.connection.once('open', async () => {
    try {
        // Remove legacy unique index on className to allow duplicate class names with unique sections
        try {
            await Class.collection.dropIndex('className_1');
        } catch (dropErr) {
            // Ignore if index does not exist
        }

        await ensureBaseClasses();
        const result = await bootstrapFromExcelIfEmpty();
        if (result && result.message) {
            console.log('[bootstrap]', result.message);
        }

        await ensureAdminUser();
    } catch (err) {
        console.error('[bootstrap] Failed to import students from Excel:', err.message);
    }
});

// ============== HOME & SETUP ROUTES ==============

// 1. Home Route - Serve login page
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html', (err) => {
        if (err) {
            console.error('Error sending file:', err);
            res.status(500).send('Error loading login page');
        }
    });
});

// 2. Setup Route - Initialize database with sample data
app.get('/setup', checkDBConnection, async (req, res) => {
    try {
        const timeoutPromise = new Promise((_, reject) =>
            setTimeout(() => reject(new Error('Setup timeout after 20 seconds')), 20000)
        );

        const setupPromise = (async () => {
            const existingUsers = await User.countDocuments();

            if (existingUsers > 0) {
                return `<h1>Database Already Initialized!</h1><p><strong>Admin:</strong> ID: ${DEFAULT_ADMIN_USER_ID} | Password: ${DEFAULT_ADMIN_PASSWORD}</p><p><strong>Student:</strong> ID: 10011 | Password: ${DEFAULT_STUDENT_PASSWORD}</p>`;
            }

            // Create classes
            const classes = await Class.create([
                { className: "Class A", section: "Section 1", semester: "Sem 1" },
                { className: "Class B", section: "Section 2", semester: "Sem 1" },
                { className: "Class C", section: "Section 3", semester: "Sem 2" }
            ]);

            // Create admin & students
            const users = await User.create([
                { userId: DEFAULT_ADMIN_USER_ID, password: DEFAULT_ADMIN_PASSWORD, role: "admin", firstName: "Admin", lastName: "User", email: DEFAULT_ADMIN_EMAIL },
                { userId: "10011", studentId: "10011", password: DEFAULT_STUDENT_PASSWORD, role: "student", firstName: "John", lastName: "Doe", email: "john@student.com", classId: classes[0]._id },
                { userId: "10012", studentId: "10012", password: DEFAULT_STUDENT_PASSWORD, role: "student", firstName: "Jane", lastName: "Smith", email: "jane@student.com", classId: classes[0]._id },
                { userId: "10013", studentId: "10013", password: DEFAULT_STUDENT_PASSWORD, role: "student", firstName: "Mike", lastName: "Johnson", email: "mike@student.com", classId: classes[1]._id },
                { userId: "10014", studentId: "10014", password: DEFAULT_STUDENT_PASSWORD, role: "student", firstName: "Sarah", lastName: "Williams", email: "sarah@student.com", classId: classes[1]._id }
            ]);

            // Create sample attendance records
            const startDate = new Date('2024-01-15');
            const attendanceRecords = [];
            for (let i = 0; i < 30; i++) {
                for (let j = 1; j < users.length; j++) { // Skip admin
                    attendanceRecords.push({
                        studentId: users[j]._id,
                        classId: users[j].classId,
                        date: new Date(startDate.getTime() + i * 24 * 60 * 60 * 1000),
                        status: Math.random() > 0.1 ? 'present' : 'absent',
                        markedBy: users[0]._id
                    });
                }
            }
            await Attendance.insertMany(attendanceRecords);

            return `<h1>Database Initialized Successfully!</h1><p><strong>Admin:</strong> ID: ${DEFAULT_ADMIN_USER_ID} | Password: ${DEFAULT_ADMIN_PASSWORD}</p><p><strong>Students:</strong> ID: 10011-10014 | Password: ${DEFAULT_STUDENT_PASSWORD}</p><p><a href="/">Go to Login</a></p>`;
        })();

        const result = await Promise.race([setupPromise, timeoutPromise]);
        res.send(result);
    } catch (err) {
        console.error('Setup error:', err);
        res.status(500).send("<h1>❌ Setup Error</h1><p>" + err.message + "</p><p>Make sure MongoDB is connected and try again.</p>");
    }
});

// ============== AUTHENTICATION ==============

// 3. Login Route — FIX: find user first, then compare password separately
app.post('/login', checkDBConnection, async (req, res) => {
    const { userId, password, role } = req.body;

    // Debug logs — remove after confirming login works
    console.log('[login] Attempt:', {
        userId: userId,
        passwordLength: password?.length,
        role: role
    });

    const normalizedUserId   = (userId   || '').toString().trim();
    const normalizedPassword = (password || '').toString();
    const normalizedRole     = (role     || '').toString().trim().toLowerCase();

    if (!normalizedUserId || !normalizedPassword || !['admin', 'student'].includes(normalizedRole)) {
        return res.status(400).json({ success: false, message: 'Invalid login payload' });
    }

    try {
        // FIX: Query by userId + role ONLY — never include password in the query
        const user = await User.findOne({
            userId: normalizedUserId,
            role:   normalizedRole
        }).populate('classId');

        console.log('[login] DB lookup:', user
            ? { userId: user.userId, role: user.role, passwordType: user.password?.startsWith('$2') ? 'bcrypt' : 'plain-text' }
            : 'NOT FOUND'
        );

        if (!user) {
            return res.json({ success: false, message: "Invalid ID or Password" });
        }

        // FIX: Compare password — handles both bcrypt-hashed and plain-text passwords
        let passwordMatch = false;
        if (user.password && user.password.startsWith('$2')) {
            // Password is a bcrypt hash — must use bcrypt.compare()
            const bcrypt = require('bcrypt');
            passwordMatch = await bcrypt.compare(normalizedPassword, user.password);
        } else {
            // Password is stored as plain text — direct compare
            passwordMatch = (user.password === normalizedPassword);
        }

        console.log('[login] Password match result:', passwordMatch);

        if (!passwordMatch) {
            return res.json({ success: false, message: "Invalid ID or Password" });
        }

        return res.json({
            success: true,
            message: "Login successful!",
            user: {
                userId:    user.userId,
                role:      user.role,
                name:      user.name || `${user.firstName || ''} ${user.lastName || ''}`.trim(),
                classId:   user.classId?._id   || null,
                className: user.classId?.className || null
            }
        });

    } catch (error) {
        console.error('[login] Error:', error.message);
        return res.status(500).json({ success: false, message: "Database Error" });
    }
});

// ============== ADMIN HELPERS ==============

async function getNextStudentIdValue() {
    const maxExisting = await fetchMaxStudentNumber();
    const nextNum = (maxExisting || 0) + 1;
    const candidate = formatStudentId(nextNum);
    const exists = await User.exists({
        $or: [{ studentId: candidate }, { userId: candidate }]
    });

    if (!exists) return candidate;

    // Fallback to fully unique generator if the simple next value collides
    const { studentId } = await generateUniqueStudentId();
    return studentId;
}

// FIX Bug #3: ensureAdminUser now throws on failure so caller (bootstrap) can log it properly
async function ensureAdminUser() {
    const existing = await User.findOne({ role: 'admin' }).lean();
    if (existing) {
        console.log('[bootstrap] Admin already exists. userId:', existing.userId);
        return;
    }

    const defaultAdmin = {
        userId:    DEFAULT_ADMIN_USER_ID,
        password:  DEFAULT_ADMIN_PASSWORD,
        role:      'admin',
        firstName: 'Admin',
        lastName:  'User',
        email:     DEFAULT_ADMIN_EMAIL
    };

    // FIX: No try/catch here — let errors propagate so the caller knows if admin wasn't created
    await User.create(defaultAdmin);
    console.log('[bootstrap] Default admin created. ID:', DEFAULT_ADMIN_USER_ID);
}

// ============== ADMIN ROUTES ==============

// 4. Get Dashboard Stats (Admin)
app.get('/api/admin/stats', checkDBConnection, async (req, res) => {
    try {
        const totalStudents = await User.countDocuments({ role: 'student' });
        const totalClasses = await Class.countDocuments();
        const todayDate = new Date().toDateString();
        const todayAttendance = await Attendance.countDocuments({
            date: {
                $gte: new Date(todayDate),
                $lt: new Date(new Date(todayDate).getTime() + 24 * 60 * 60 * 1000)
            },
            status: 'present'
        });
        const totalRecords = await Attendance.countDocuments();
        const presentCount = await Attendance.countDocuments({ status: 'present' });
        const avgAttendance = totalRecords > 0 ? ((presentCount / totalRecords) * 100).toFixed(2) : 0;

        // Weekly trend (last 7 days)
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const todayEnd = new Date(today);
        todayEnd.setHours(23, 59, 59, 999);
        const weekStart = new Date(today);
        weekStart.setDate(today.getDate() - 6);

        const weekly = await Attendance.aggregate([
            { $match: { date: { $gte: weekStart, $lte: todayEnd } } },
            {
                $group: {
                    _id: { $dateToString: { format: "%Y-%m-%d", date: "$date" } },
                    total: { $sum: 1 },
                    present: { $sum: { $cond: [{ $eq: ["$status", "present"] }, 1, 0] } }
                }
            },
            { $sort: { _id: 1 } }
        ]);

        const weeklyTrend = weekly.map(item => ({
            date: item._id,
            present: item.present,
            total: item.total,
            percentage: item.total > 0 ? ((item.present / item.total) * 100).toFixed(2) : 0
        }));

        res.json({ totalStudents, totalClasses, avgAttendance, todayPresent: todayAttendance, weeklyTrend });
    } catch (error) {
        res.status(500).json({ success: false, message: "Error fetching stats", error: error.message });
    }
});

// 4b. Trigger Excel import manually (Admin)
app.post('/api/admin/import-students', checkDBConnection, async (req, res) => {
    try {
        const filePath = req.body && req.body.filePath ? req.body.filePath : undefined;
        const result = await importStudentsFromExcel(filePath);
        res.json(result);
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 5. Get All Students (Admin)
app.get('/api/admin/students', checkDBConnection, async (req, res) => {
    try {
        console.log('[students] Fetching all students...');
        const students = await User.find({ role: 'student' })
            .lean()
            .maxTimeMS(30000);

        const rows = students.map((student) => {
            const clone = { ...student };
            delete clone.password;
            delete clone.__v;
            return clone;
        });

        const columns = rows.length
            ? Object.keys(rows[0]).filter(key => ![
                '_id', 'userId', 'studentId', 'role', 'password', 'classId',
                'attendance', 'createdAt', 'updatedAt', '__v', 'name',
                'firstName', 'lastName', 'guardianName', 'motherName',
                'motherEmail', 'motherMobile', 'fatherName', 'fatherEmail', 'fatherMobile'
              ].includes(key))
            : [];

        console.log(`[students] Found ${rows.length} rows`);
        res.json({ success: true, columns, rows });
    } catch (error) {
        console.error('[students] Error:', error.message);
        res.status(500).json({ success: false, message: 'Error fetching students: ' + error.message });
    }
});

// 5b. Get next Student ID (Admin)
app.get('/api/admin/students/next-id', checkDBConnection, async (req, res) => {
    try {
        const nextId = await getNextStudentIdValue();
        res.json({ success: true, nextId });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 6. Add Student (Admin)
app.post('/api/admin/students', checkDBConnection, async (req, res) => {
    try {
        const { userId, name, guardianName, phone, email, classId } = req.body;

        if (!name || !guardianName || !phone || !classId) {
            return res.json({ success: false, message: "Name, guardian name, phone and class are required" });
        }

        const nameParts = name.trim().split(/\s+/);
        const firstName = nameParts[0];
        const lastName = nameParts.slice(1).join(' ') || '';

        // Auto-generate student ID if not provided
        let newUserId = (userId || '').trim();
        if (newUserId) {
            const numeric = extractNumericSuffix(newUserId) || (await fetchMaxStudentNumber()) + 1;
            newUserId = formatStudentId(numeric);
        } else {
            const { studentId } = await generateUniqueStudentId();
            newUserId = studentId;
        }

        // Ensure uniqueness even under race conditions
        let collision = await User.exists({
            $or: [{ userId: newUserId }, { studentId: newUserId }]
        });
        let bumpCounter = extractNumericSuffix(newUserId) || (await fetchMaxStudentNumber()) + 1;
        while (collision) {
            bumpCounter += 1;
            newUserId = formatStudentId(bumpCounter);
            collision = await User.exists({
                $or: [{ userId: newUserId }, { studentId: newUserId }]
            });
        }

        console.log('[add-student] generated userId:', newUserId);

        // Check if student already exists
        const existingStudent = await User.findOne({
            $or: [
                { userId: newUserId },
                { studentId: newUserId },
                { name: name.trim(), phone: phone.trim() },
                { name: name.trim(), email: (email || '').trim() }
            ]
        });
        if (existingStudent) {
            return res.json({ success: false, message: "Student already exists (duplicate ID or name/phone)" });
        }

        const payload = {
            userId:       newUserId,
            studentId:    newUserId,
            name:         name.trim(),
            firstName,
            lastName,
            email:        email || '',
            phone:        phone.trim(),
            password:     DEFAULT_STUDENT_PASSWORD,
            role:         "student",
            classId,
            guardianName: guardianName.trim()
        };

        let attempts = 0;
        while (attempts < 3) {
            try {
                const student = await User.create(payload);
                return res.json({ success: true, message: "Student added successfully", student });
            } catch (error) {
                if (error && error.code === 11000) {
                    const regenerated = await generateUniqueStudentId();
                    payload.userId = regenerated.studentId;
                    payload.studentId = regenerated.studentId;
                    attempts++;
                    continue;
                }
                throw error;
            }
        }

        res.status(500).json({ success: false, message: 'Could not allocate a unique student ID. Please retry.' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 7. Edit Student (Admin)
app.put('/api/admin/students/:studentId', checkDBConnection, async (req, res) => {
    try {
        const { name, guardianName, phone, email, classId } = req.body;

        if (!name || !guardianName || !phone || !classId) {
            return res.json({ success: false, message: "Name, guardian name, phone and class are required" });
        }

        const existingStudent = await User.findById(req.params.studentId);
        if (!existingStudent) {
            return res.json({ success: false, message: "Student not found" });
        }

        const nameParts = name.trim().split(/\s+/);
        const firstName = nameParts[0];
        const lastName = nameParts.slice(1).join(' ') || '';

        // Prevent duplicates on update (name + phone)
        const duplicate = await User.findOne({
            _id: { $ne: req.params.studentId },
            $or: [
                { name: name.trim(), phone: phone.trim() },
                { name: name.trim(), email: (email || '').trim() }
            ]
        });
        if (duplicate) {
            return res.json({ success: false, message: "Another student with the same name and phone exists" });
        }

        const updatePayload = {
            name:         name.trim(),
            firstName,
            lastName,
            email:        email || '',
            phone:        phone.trim(),
            classId,
            guardianName: guardianName.trim()
        };

        if (!existingStudent.studentId && existingStudent.userId) {
            updatePayload.studentId = existingStudent.userId;
        }

        const student = await User.findByIdAndUpdate(
            req.params.studentId,
            updatePayload,
            { new: true }
        ).populate('classId');

        res.json({ success: true, message: "Student updated successfully", student });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 8. Delete Student (Admin)
app.delete('/api/admin/students/:studentId', checkDBConnection, async (req, res) => {
    try {
        await User.findByIdAndDelete(req.params.studentId);
        await Attendance.deleteMany({ studentId: req.params.studentId });
        res.json({ success: true, message: "Student deleted successfully" });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 9. Get All Classes (Admin)
app.get('/api/admin/classes', checkDBConnection, async (req, res) => {
    try {
        const classes = await Class.find().lean();

        // Get student count and attendance for each class
        for (let cls of classes) {
            cls.studentCount = await User.countDocuments({ classId: cls._id, role: 'student' });
            const presentCount = await Attendance.countDocuments({ classId: cls._id, status: 'present' });
            const totalRecords = await Attendance.countDocuments({ classId: cls._id });
            cls.attendancePercentage = totalRecords > 0 ? ((presentCount / totalRecords) * 100).toFixed(2) : 0;
        }

        res.json({ success: true, classes });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 10. Add Class (Admin)
app.post('/api/admin/classes', checkDBConnection, async (req, res) => {
    try {
        const classNameInput = (req.body.className || '').trim();
        const sectionInput   = (req.body.section   || '').trim();
        const semester       = req.body.semester;

        const duplicateSection = await Class.findOne({
            className: new RegExp(`^${classNameInput}$`, 'i'),
            section:   new RegExp(`^${sectionInput}$`,   'i')
        });

        if (duplicateSection) {
            return res.json({ success: false, message: "Section already exists for this class" });
        }

        const newClass = await Class.create({ className: classNameInput, section: sectionInput, semester });
        res.json({ success: true, message: "Class created successfully", class: newClass });
    } catch (error) {
        if (error && error.code === 11000) {
            return res.json({ success: false, message: "Section already exists for this class" });
        }
        res.status(500).json({ success: false, message: error.message });
    }
});

// 10b. Delete Class (Admin)
app.delete('/api/admin/classes/:classId', checkDBConnection, async (req, res) => {
    try {
        const classId = req.params.classId;
        const classDoc = await Class.findById(classId);
        if (!classDoc) {
            return res.json({ success: false, message: "Class not found" });
        }

        await Class.deleteOne({ _id: classId });
        const detachResult     = await User.updateMany({ classId }, { $set: { classId: null } });
        const attendanceResult = await Attendance.deleteMany({ classId });

        res.json({
            success: true,
            message: "Class deleted successfully",
            detachedStudents:   detachResult.modifiedCount   || 0,
            removedAttendance:  attendanceResult.deletedCount || 0
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 11. Get Class Details with Students (Admin)
app.get('/api/admin/classes/:classId', checkDBConnection, async (req, res) => {
    try {
        const classData = await Class.findById(req.params.classId);
        const students  = await User.find({ classId: req.params.classId, role: 'student' }).select('-password');

        for (let student of students) {
            const totalDays   = await Attendance.countDocuments({ studentId: student._id });
            const presentDays = await Attendance.countDocuments({ studentId: student._id, status: 'present' });
            student.attendancePercentage = totalDays > 0 ? ((presentDays / totalDays) * 100).toFixed(2) : 0;
            student.displayName = student.name || `${student.firstName} ${student.lastName}`.trim();
        }

        res.json({ success: true, class: classData, students });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 12. Mark Attendance (Admin)
app.post('/api/admin/attendance', checkDBConnection, async (req, res) => {
    try {
        const { studentId, classId, date, status, markedBy } = req.body;
        const attendanceDate = new Date(date);
        attendanceDate.setHours(0, 0, 0, 0);

        const record = await Attendance.findOneAndUpdate(
            { studentId, classId, date: attendanceDate },
            { $set: { status, markedBy, date: attendanceDate } },
            { new: true, upsert: true }
        );

        res.json({ success: true, message: "Attendance saved", record });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 12b. Notify Parents of Absence (Admin)
app.post('/api/admin/notify-parents', checkDBConnection, async (req, res) => {
    try {
        const { studentId, studentName, parentEmails, parentPhones, date, notificationType } = req.body;
        const notificationResults = [];

        if (parentEmails && parentEmails.length > 0) {
            for (let parent of parentEmails) {
                try {
                    const notificationLog = {
                        studentId,
                        studentName,
                        parentType:  parent.parentType,
                        parentName:  parent.parentName,
                        parentEmail: parent.email,
                        date:        new Date(date),
                        notificationType,
                        sentAt: new Date(),
                        status: 'sent'
                    };

                    console.log('📧 Email Notification:', {
                        to:      parent.email,
                        subject: `Absence Notification - ${studentName}`,
                        body:    `Dear ${parent.parentName || parent.parentType},\n\nThis is to inform you that ${studentName} was marked absent on ${date}.\n\nPlease contact the school if you have any questions.\n\nBest regards,\nSchool Administration`
                    });

                    notificationResults.push(notificationLog);
                } catch (error) {
                    console.error(`Error sending notification to ${parent.email}:`, error);
                }
            }
        }

        if (parentPhones && parentPhones.length > 0) {
            for (let parent of parentPhones) {
                try {
                    console.log('📱 SMS Notification:', {
                        to:      parent.phone,
                        message: `Dear ${parent.parentName || parent.parentType}, ${studentName} was marked absent on ${date}. Please contact school if needed.`
                    });
                } catch (error) {
                    console.error(`Error sending SMS to ${parent.phone}:`, error);
                }
            }
        }

        res.json({
            success: true,
            message: `Notifications sent to ${notificationResults.length} parent(s)`,
            notifications: notificationResults
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 13. Get Monthly Attendance Report (Admin)
app.get('/api/admin/reports/monthly', checkDBConnection, async (req, res) => {
    try {
        const classId = req.query.classId;
        const year    = parseInt(req.query.year)  || new Date().getFullYear();
        const month   = parseInt(req.query.month) || new Date().getMonth();

        const startDate = new Date(year, month, 1);
        const endDate   = new Date(year, month + 1, 0);

        const report = await Attendance.aggregate([
            {
                $match: {
                    classId: mongoose.Types.ObjectId(classId),
                    date: { $gte: startDate, $lte: endDate }
                }
            },
            {
                $group: {
                    _id: { $dateToString: { format: "%Y-%m-%d", date: "$date" } },
                    present: { $sum: { $cond: [{ $eq: ["$status", "present"] }, 1, 0] } },
                    absent:  { $sum: { $cond: [{ $eq: ["$status", "absent"]  }, 1, 0] } }
                }
            },
            { $sort: { _id: 1 } }
        ]);

        res.json({ success: true, report });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// ============== STUDENT ROUTES ==============

// 14. Get Student Dashboard (Student)
app.get('/api/student/dashboard/:userId', checkDBConnection, async (req, res) => {
    try {
        const student = await User.findOne({ userId: req.params.userId, role: 'student' }).populate('classId');

        if (!student) {
            return res.status(404).json({ success: false, message: "Student not found" });
        }

        const totalDays   = await Attendance.countDocuments({ studentId: student._id });
        const presentDays = await Attendance.countDocuments({ studentId: student._id, status: 'present' });
        const attendancePercentage = totalDays > 0 ? ((presentDays / totalDays) * 100).toFixed(2) : 0;

        res.json({
            success: true,
            student: {
                name:                `${student.firstName} ${student.lastName}`,
                email:               student.email,
                phone:               student.phone,
                className:           student.classId?.className,
                userId:              student.userId,
                attendancePercentage,
                totalDays,
                presentDays,
                absentDays:          totalDays - presentDays
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 15. Get Student Attendance History (Student)
app.get('/api/student/attendance/:userId', checkDBConnection, async (req, res) => {
    try {
        const student = await User.findOne({ userId: req.params.userId });

        // FIX: guard against student not found before accessing ._id
        if (!student) {
            return res.status(404).json({ success: false, message: "Student not found" });
        }

        const attendanceRecords = await Attendance.find({ studentId: student._id })
            .sort({ date: -1 })
            .limit(30);

        res.json({ success: true, records: attendanceRecords });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// ============== START SERVER ==============

app.listen(PORT, () => {
    console.log(`🚀 Server is officially running at http://localhost:${PORT}`);
});
