// Backend API base URL (Express). Keep this as an HTTP(S) or relative API path, never a MongoDB URI.
const API_URL = '/api';
const STUDENT_API_URL = 'https://script.google.com/macros/s/AKfycbwii_5emJo_9Jv1SRlqEBKF4AIQNZrPr2hYRMMJ4H5tTRLzwlkCSw3c5NFq9J1vqQ6F/exec';

const appState = {
    currentSection: 'dashboard',
    stats: {},
    students: [],
    studentColumns: [],
    classes: [],
    attendance: {},
    threshold: localStorage.getItem('attendanceThreshold') || 85,
    charts: {},
    editingStudentId: null,
    loading: false,
    attendanceSnapshots: {} 
};

const backendEnabled = () => typeof API_URL === 'string' && API_URL.trim().length > 0;


document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    initializeUI();
    setupNavigationListeners();
    setupEventListeners();
    loadAllData();
    setupModalHandlers();
});

function checkAuth() {
    const userRole = localStorage.getItem('userRole');
    const userId = localStorage.getItem('userId');
    
    if (userRole !== 'admin' || !userId) {
        window.location.href = 'index.html';
        return;
    }

    const userName = localStorage.getItem('userName') || 'Admin';
    document.getElementById('userName').textContent = userName;
}

function initializeUI() {
    // Set today's date in attendance section
    const todayInput = document.getElementById('attendanceDate');
    if (todayInput) {
        todayInput.valueAsDate = new Date();
    }

    // Set initial threshold value
    const thresholdInput = document.getElementById('thresholdInput');
    if (thresholdInput) {
        thresholdInput.value = appState.threshold;
    }
}

async function loadAllData() {
    showLoading(true);
    try {
        await loadStudents();
        await loadClasses();
        await loadStats();
        setupCharts();
    } catch (error) {
        console.error('Error loading data:', error);
    }
    showLoading(false);
}


function setupNavigationListeners() {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = e.currentTarget.dataset.section;
            switchSection(section);
        });
    });

    document.getElementById('menuToggle')?.addEventListener('click', toggleSidebar);
    document.getElementById('sidebarToggle')?.addEventListener('click', toggleSidebar);
}

function switchSection(section) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    
    // Show selected section
    const targetSection = document.getElementById(section);
    if (targetSection) {
        targetSection.classList.add('active');
    }

    // Update nav highlighting
    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
    const navItem = document.querySelector(`[data-section="${section}"]`);
    if (navItem) {
        navItem.classList.add('active');
    }

    // Update page title
    const titles = {
        dashboard: 'Dashboard',
        students: 'Student Management',
        classes: 'Class Management',
        attendance: 'Mark Attendance',
        reports: 'Reports & Analytics',
        settings: 'Settings'
    };
    const titleElement = document.querySelector('.page-title');
    if (titleElement) {
        titleElement.textContent = titles[section] || 'Dashboard';
    }

    appState.currentSection = section;

    // Reload specific section data
    if (section === 'dashboard') {
        setTimeout(() => setupCharts(), 100);
    } else if (section === 'classes') {
        loadClasses();
    } else if (section === 'attendance') {
        populateAttendanceClassSelect();
    }
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
        sidebar.classList.toggle('active');
    }
}

// ==================== STATS AND DASHBOARD ====================

async function loadStats() {
    // Local stats derived from sheet + last marked attendance (no backend credentials required)
    const totalStudents = appState.students.length;
    const totalClasses = appState.classes.length;
    const classPercents = appState.classes.map(c => parseFloat(c.attendancePercentage || 0));
    const avgAttendance = classPercents.length
        ? (classPercents.reduce((a, b) => a + b, 0) / classPercents.length).toFixed(2)
        : 0;

    appState.stats = {
        totalStudents,
        totalClasses,
        todayPresent: 0,
        avgAttendance,
        weeklyTrend: []
    };

    document.getElementById('totalStudents').textContent = totalStudents;
    document.getElementById('totalClasses').textContent = totalClasses;
    document.getElementById('todayPresent').textContent = 0;
    document.getElementById('avgAttendance').textContent = avgAttendance + '%';

    populateClassSelects();
    setupCharts();
}

// ==================== STUDENT MANAGEMENT ====================


async function loadStudents() {
    const tbody = document.getElementById('studentsTable');
    if (tbody) {
        const colCount = (appState.studentColumns.length || 7) + 1; // +1 for Actions
        tbody.innerHTML = `<tr><td colspan="${colCount}" class="text-center">Loading students...</td></tr>`;
    }
    showLoading(true);
    try {
        const response = await fetch(STUDENT_API_URL, { method: 'GET' });
        const data = await response.json();

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        // API returns array of objects keyed by headers
        const rows = Array.isArray(data) ? data : Array.isArray(data?.data) ? data.data : [];
        const columns = ['ID', 'Name', 'Class', 'GuardianName', 'Phone', 'Email', 'Attendance'];

        console.debug('[students] fetched', rows.length);
        appState.students = rows;
        appState.studentColumns = columns;

        displayStudents(appState.students, appState.studentColumns);
        // Update dashboard counts immediately from sheet data
        document.getElementById('totalStudents').textContent = appState.students.length;
        // Rebuild classes from sheet data when backend is disabled
        if (!backendEnabled()) {
            appState.classes = sortClasses(buildClassesFromStudents());
            displayClasses(appState.classes);
            populateClassSelects();
            setupCharts();
        }
    } catch (error) {
        console.error('Error loading students:', error);
        showNotification('Error loading students: ' + error.message, 'error');
        if (tbody) {
            const colCount = (appState.studentColumns.length || 7) + 1;
            tbody.innerHTML = `<tr><td colspan="${colCount}" class="text-center">Could not load students</td></tr>`;
        }
    } finally {
        showLoading(false);
    }
}

function displayStudents(students, columns = []) {
    const tbody = document.getElementById('studentsTable');
    const headerRow = document.querySelector('#students .data-table thead tr');
    if (!tbody || !headerRow) return;

    const safeColumns = columns.length ? columns : ['ID', 'Name', 'Class', 'GuardianName', 'Phone', 'Email', 'Attendance'];

    // Build header
    headerRow.innerHTML = safeColumns.map(col => `<th>${col}</th>`).join('') + '<th>Actions</th>';

    tbody.innerHTML = '';

    if (students.length === 0) {
        tbody.innerHTML = `<tr><td colspan="${safeColumns.length + 1}" class="text-center">No students found</td></tr>`;
        return;
    }

    students.forEach(student => {
        const row = document.createElement('tr');
        const cells = safeColumns.map(col => `<td>${student[col] ?? '-'}</td>`).join('');
        const actions = `
            <td class="action-buttons">
                <button class="btn btn-sm btn-info" onclick="editStudent('${student.ID || student.id || ''}')">
                    <i class="fas fa-edit"></i> Edit
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteStudent('${student.ID || student.id || ''}')">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </td>
        `;
        row.innerHTML = cells + actions;
        tbody.appendChild(row);
    });
}


async function deleteClass(classId, className) {
    if (!confirm(`Delete ${className}? Students will be unassigned and attendance records for this class will be removed.`)) {
        return;
    }

    // In sheet-only mode, inform the user
    if (!backendEnabled()) {
        showNotification('Delete classes directly in the Google Sheet (backend disabled).', 'warning');
        return;
    }

    showLoading(true);
    try {
        const response = await fetch(`${API_URL}/admin/classes/${classId}`, { method: 'DELETE' });
        const data = await response.json();
        if (data.success) {
            showNotification('Class deleted successfully', 'success');
            await loadClasses();
            await loadStudents();
            await loadStats();
        } else {
            showNotification(data.message || 'Error deleting class', 'error');
        }
    } catch (error) {
        console.error('Error deleting class:', error);
        showNotification('Error deleting class', 'error');
    }
    showLoading(false);
}

function setNextSheetStudentId() {
    const idInput = document.getElementById('formStudentId');
    if (!idInput) return;
    const maxNum = appState.students.reduce((max, row) => {
        const idVal = row.ID || row.Id || row.id || row.userId || '';
        const num = parseInt((idVal || '').toString().replace(/\D+/g, ''), 10);
        return Number.isNaN(num) ? max : Math.max(max, num);
    }, 0);
    const next = maxNum + 1;
    idInput.value = `STU${String(next).padStart(3, '0')}`;
}

function openAddStudentModal() {
    appState.editingStudentId = null;
    document.getElementById('studentForm').reset();
    document.getElementById('studentModalTitle').textContent = 'Add New Student';
    document.getElementById('studentModal').classList.add('active');
    populateClassSelects();
    setNextSheetStudentId();
}

function editStudent(studentId) {
    const student = appState.students.find(s => (s.ID || s.id) === studentId);
    if (!student) return;

    appState.editingStudentId = studentId;

    document.getElementById('formStudentId').value = student.ID || student.id || '';
    document.getElementById('formStudentName').value = student.Name || '';
    document.getElementById('formGuardianName').value = student.GuardianName || '';
    document.getElementById('formEmail').value = student.Email || '';
    document.getElementById('formPhone').value = student.Phone || '';
    document.getElementById('formClassId').value = student.Class || '';

    document.getElementById('studentModalTitle').textContent = 'Edit Student';
    document.getElementById('studentModal').classList.add('active');
}

async function deleteStudent(studentId) {
    alert('Delete is not supported with Google Sheets backend. Please remove the row directly in the sheet.');
}

async function handleStudentFormSubmit(e) {
    e.preventDefault();

    const payload = {
        ID: document.getElementById('formStudentId').value.trim(),
        Name: document.getElementById('formStudentName').value.trim(),
        Class: document.getElementById('formClassId').value,
        GuardianName: document.getElementById('formGuardianName').value.trim(),
        Phone: document.getElementById('formPhone').value.trim(),
        Email: document.getElementById('formEmail').value.trim(),
        Attendance: 0
    };

    // Validation
    const requiredFields = [
        { id: 'formStudentName', value: payload.Name },
        { id: 'formGuardianName', value: payload.GuardianName },
        { id: 'formPhone', value: payload.Phone },
        { id: 'formClassId', value: payload.Class }
    ];

    let invalid = false;
    requiredFields.forEach(field => {
        const el = document.getElementById(field.id);
        if (!field.value) {
            invalid = true;
            el.classList.add('invalid');
        } else {
            el.classList.remove('invalid');
        }
    });

    if (invalid) {
        showNotification('Please fill all required fields', 'error');
        return;
    }

    showLoading(true);
    try {
        const response = await fetch(STUDENT_API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        let data;
        try {
            data = await response.json();
        } catch (err) {
            const text = await response.text();
            throw new Error(text || 'Invalid response from Sheets API');
        }

        if (!response.ok || (data.status && data.status !== 'success')) {
            throw new Error(data.message || `HTTP ${response.status}: ${response.statusText}`);
        }

        showNotification('Student saved to sheet', 'success');
        closeModal('studentModal');
        await loadStudents();
        await loadClasses();
        await loadStats();
    } catch (error) {
        console.error('Error saving student:', error);
        showNotification('Error saving student', 'error');
    }
    showLoading(false);
}

function handleStudentSearch(e) {
    const query = e.target.value.toLowerCase();
    const cols = appState.studentColumns;
    const filtered = appState.students.filter(row =>
        cols.some(col => (row[col] || '').toString().toLowerCase().includes(query))
    );
    displayStudents(filtered, appState.studentColumns);
}

function handleClassFilter(e) {
    const classId = e.target.value;
    const filtered = classId
        ? appState.students.filter(s => (s.Class || s.class || '').toString() === classId)
        : appState.students;
    displayStudents(filtered, appState.studentColumns);
}

// ==================== CLASS MANAGEMENT ====================

async function loadClasses() {
    try {
        if (backendEnabled()) {
            const response = await fetch(`${API_URL}/admin/classes`);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            const data = await response.json();

            if (data.success && data.classes && data.classes.length) {
                appState.classes = sortClasses(data.classes);
            } else {
                appState.classes = sortClasses(buildClassesFromStudents());
            }
        } else {
            // Sheet-only mode: derive classes directly from students
            appState.classes = sortClasses(buildClassesFromStudents());
        }

        displayClasses(appState.classes);
        populateClassSelects();
        setupCharts();
        document.getElementById('totalClasses').textContent = appState.classes.length;
    } catch (error) {
        console.error('Error loading classes:', error);
        appState.classes = sortClasses(buildClassesFromStudents());
        displayClasses(appState.classes);
        populateClassSelects();
    }
}

function buildClassesFromStudents() {
    const byClass = new Map();
    appState.students.forEach(s => {
        const className = (s.Class || '').toString().trim();
        if (!className) return;
        if (!byClass.has(className)) {
            byClass.set(className, { _id: className, className, section: '', semester: '', studentCount: 0, attendancePercentage: 0 });
        }
        byClass.get(className).studentCount += 1;
    });
    return Array.from(byClass.values());
}

function sortClasses(list = []) {
    return [...list].sort((a, b) => {
        const numA = parseInt((a.className || '').toString().replace(/\D+/g, ''), 10) || 0;
        const numB = parseInt((b.className || '').toString().replace(/\D+/g, ''), 10) || 0;
        if (numA !== numB) return numA - numB;
        return (a.className || '').localeCompare(b.className || '');
    });
}

function displayClasses(classes) {
    const grid = document.getElementById('classesGrid');
    if (!grid) return;

    grid.innerHTML = '';

    if (classes.length === 0) {
        grid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: #999;">No classes found</p>';
        return;
    }

    classes.forEach(cls => {
        const card = document.createElement('div');
        card.className = 'class-card';
        card.style.borderLeftColor = '#667eea';
        
        card.innerHTML = `
            <div class="class-header">
                <h3>${cls.className}</h3>
                <span class="class-section">${cls.section || 'No Section'}</span>
            </div>
            <div class="class-body">
                <p><strong>Students:</strong> <span style="font-size: 1.2em; color: #667eea;">${cls.studentCount || 0}</span></p>
                <p><strong>Semester:</strong> ${cls.semester || 'N/A'}</p>
            </div>
            <div class="class-actions">
                <button class="btn btn-sm btn-info" onclick="viewClassDetails('${cls._id}', '${cls.className}')">
                    <i class="fas fa-eye"></i> View Details
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteClass('${cls._id}', '${cls.className}')">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        grid.appendChild(card);
    });
}

async function viewClassDetails(classId, className) {
    showLoading(true);
    try {
        let students = [];
        let classLabel = className;
        if (backendEnabled()) {
            try {
                const response = await fetch(`${API_URL}/admin/classes/${classId}`);
                const data = await response.json();
                if (response.ok && data.success) {
                    students = data.students || [];
                    classLabel = data.class?.className || className;
                }
            } catch (_) { /* fallback below */ }
        }

        // Fallback to sheet data if backend empty
        if (!students.length) {
            const cls = appState.classes.find(c => c._id === classId);
            const classNameFromSheet = cls?.className || classId;
            classLabel = classNameFromSheet;
            const snapshot = appState.attendanceSnapshots[classId] || [];
            students = appState.students
                .filter(s => (s.Class || '').toString().trim() === classNameFromSheet)
                .map(s => {
                    const snap = snapshot.find(x => x.userId === (s.ID || s.id || s.Name));
                    return {
                        userId: s.ID || s.id || '',
                        displayName: s.Name || '',
                        attendancePercentage: snap ? snap.attendancePercentage : 0
                    };
                });
        }

        if (!students.length) {
            showNotification('No students in this class', 'warning');
            showLoading(false);
            return;
        }

        const threshold = parseInt(appState.threshold);
        let html = `
            <h3 style="margin-bottom: 1.5rem;">${classLabel} - Details</h3>
            <table class="data-table" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>Student ID</th>
                        <th>Attendance %</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
        `;

        students.forEach(student => {
            const displayName = student.displayName || student.name || student.Name || `${student.firstName || ''} ${student.lastName || ''}`.trim();
            const percent = parseFloat(student.attendancePercentage || 0);
            const isGood = percent >= threshold;
            const statusColor = isGood ? '#10b981' : '#ef4444';
            const statusText = isGood ? 'Good' : 'Low';

            html += `
                <tr>
                    <td><strong>${displayName}</strong></td>
                    <td>${student.userId || student.ID || ''}</td>
                    <td>
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <div style="flex: 1; background: #e5e7eb; height: 6px; border-radius: 3px; overflow: hidden;">
                                <div style="width: ${percent}%; height: 100%; background: ${statusColor};"></div>
                            </div>
                            <span style="min-width: 40px;">${percent}%</span>
                        </div>
                    </td>
                    <td><span style="color: ${statusColor}; font-weight: bold;">${statusText}</span></td>
                </tr>
            `;
        });

        html += `</tbody></table>`;

        // Calculate class average
        const avgAttendance = students.length > 0
            ? (students.reduce((sum, s) => sum + parseFloat(s.attendancePercentage || 0), 0) / students.length).toFixed(2)
            : 0;

        const classAvgColor = avgAttendance >= threshold ? '#10b981' : '#ef4444';
        html += `
            <div style="margin-top: 2rem; padding: 1rem; background: #f9fafb; border-radius: 8px;">
                <h4 style="margin: 0 0 0.5rem 0;">Class Average Attendance</h4>
                <p style="margin: 0; font-size: 2rem; color: ${classAvgColor}; font-weight: bold;">${avgAttendance}%</p>
            </div>
        `;

        document.getElementById('classDetailsContent').innerHTML = html;
        document.getElementById('classDetailsTitle').textContent = classLabel;
        document.getElementById('classDetailsModal').classList.add('active');
    } catch (error) {
        console.error('Error loading class details:', error);
        showNotification('Error loading class details', 'error');
    }
    showLoading(false);
}

function openAddClassModal() {
    document.getElementById('classForm').reset();
    document.getElementById('classModal').classList.add('active');
}

async function handleClassFormSubmit(e) {
    e.preventDefault();

    const formData = {
        className: document.getElementById('formClassName').value.trim(),
        section: document.getElementById('formSection').value.trim(),
        semester: document.getElementById('formSemester').value.trim()
    };

    if (!formData.className) {
        showNotification('Class name is required', 'error');
        return;
    }

    if (!backendEnabled()) {
        showNotification('Class creation is managed in the Google Sheet; list is auto-built from students.', 'warning');
        closeModal('classModal');
        return;
    }

    showLoading(true);
    try {
        const response = await fetch(`${API_URL}/admin/classes`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });

        const data = await response.json();

        if (data.success) {
            showNotification('Class created successfully', 'success');
            closeModal('classModal');
            await loadClasses();
            await loadStats();
            populateAttendanceClassSelect();
        } else {
            showNotification(data.message || 'Error creating class', 'error');
        }
    } catch (error) {
        console.error('Error creating class:', error);
        showNotification('Error creating class', 'error');
    }
    showLoading(false);
}

// ==================== ATTENDANCE MANAGEMENT ====================

function populateAttendanceClassSelect() {
    const select = document.getElementById('attendanceClassSelect');
    if (!select) return;

    const currentValue = select.value;
    select.innerHTML = '<option value="">Select Class</option>';

    appState.classes.forEach(cls => {
        const option = document.createElement('option');
        option.value = cls._id;
        option.textContent = cls.className;
        select.appendChild(option);
    });

    select.value = currentValue;
}

async function loadAttendanceStudents() {
    const classId = document.getElementById('attendanceClassSelect').value;
    const date = document.getElementById('attendanceDate').value;

    if (!classId || !date) {
        showNotification('Please select a class and date', 'error');
        return;
    }

    showLoading(true);
    try {
        let students = [];
        if (backendEnabled()) {
            try {
                const response = await fetch(`${API_URL}/admin/classes/${classId}`);
                const data = await response.json();
                if (response.ok && data.success) {
                    students = data.students || [];
                }
            } catch (_) {
                // ignore backend errors, fallback to sheet
            }
        }

        // Sheet fallback: filter students by Class name (classId stores className from sheet)
        if (!students.length) {
            const className = appState.classes.find(c => c._id === classId)?.className || classId;
            students = appState.students
                .filter(s => (s.Class || '').toString().trim() === className)
                .map(s => ({
                    _id: s.ID || s.id || s.Name,
                    name: s.Name,
                    firstName: s.Name,
                    lastName: '',
                    classId: classId,
                    userId: s.ID,
                    ...s
                }));
        }

        if (!students.length) {
            showNotification('No students found for this class', 'warning');
        }

        appState.attendance = {
            classId,
            date,
            students
        };
        displayAttendanceList(students);
    } catch (error) {
        console.error('Error loading students:', error);
        showNotification('Error loading students', 'error');
    }
    showLoading(false);
}

function displayAttendanceList(students) {
    const container = document.getElementById('attendanceList');
    if (!container) return;

    container.innerHTML = '';

    if (students.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #999; padding: 2rem;">No students in this class</p>';
        return;
    }

    students.forEach(student => {
        const item = document.createElement('div');
        item.className = 'attendance-item';
        const displayName = student.name || student.Name || `${student.firstName || ''} ${student.lastName || ''}`.trim();
        item.innerHTML = `
            <label class="attendance-label">
                <input type="checkbox" class="attendance-checkbox" data-student-id="${student._id || student.ID || student.id}" checked>
                <span class="attendance-student">${displayName}</span>
            </label>
            <span class="attendance-status" style="background: #10b981; color: white; padding: 0.4rem 0.8rem; border-radius: 4px;">Present</span>
        `;

        // Toggle status display on checkbox change
        const checkbox = item.querySelector('.attendance-checkbox');
        const statusSpan = item.querySelector('.attendance-status');

        checkbox.addEventListener('change', () => {
            if (checkbox.checked) {
                statusSpan.textContent = 'Present';
                statusSpan.style.background = '#10b981';
                statusSpan.style.color = 'white';
            } else {
                statusSpan.textContent = 'Absent';
                statusSpan.style.background = '#ef4444';
                statusSpan.style.color = 'white';
            }
        });

        container.appendChild(item);
    });
}

async function markAllAttendance(status) {
    const checkboxes = document.querySelectorAll('.attendance-checkbox');
    if (checkboxes.length === 0) {
        showNotification('Please load students first', 'error');
        return;
    }

    // Set all checkboxes based on status
    checkboxes.forEach(checkbox => {
        checkbox.checked = (status === 'present');
        checkbox.dispatchEvent(new Event('change'));
    });

    showNotification(`All students marked as ${status}`, 'success');
}

async function submitAttendance() {
    if (!appState.attendance.classId || !appState.attendance.date) {
        showNotification('Please load students first', 'error');
        return;
    }

    const checkboxes = document.querySelectorAll('.attendance-checkbox');
    if (checkboxes.length === 0) {
        showNotification('No students to mark', 'error');
        return;
    }

    const attendanceRecords = [];
    const adminId = localStorage.getItem('userId');
    const markedClassId = appState.attendance.classId;
    let presentCount = 0;

    checkboxes.forEach(checkbox => {
        const studentId = checkbox.dataset.studentId;
        const status = checkbox.checked ? 'present' : 'absent';
        if (status === 'present') presentCount++;

        attendanceRecords.push({
            studentId,
            classId: appState.attendance.classId,
            date: appState.attendance.date,
            status,
            markedBy: adminId
        });
    });

    showLoading(true);
    try {
        if (backendEnabled()) {
            const results = await Promise.all(attendanceRecords.map(record =>
                fetch(`${API_URL}/admin/attendance`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(record)
                }).then(res => res.json()).catch(err => ({ success: false, message: err.message }))
            ));

            const successCount = results.filter(r => r.success).length;

            if (successCount === attendanceRecords.length) {
                showNotification(`Attendance saved for ${successCount} student(s)`, 'success');
            } else {
                showNotification(`Saved ${successCount}/${attendanceRecords.length} records`, 'warning');
            }
        } else {
            showNotification('Attendance recorded locally (sheet mode).', 'info');
        }

        document.getElementById('attendanceList').innerHTML = '';
        appState.attendance = {};
        await loadStats();
        await loadClasses();
        await loadStudents();
    } catch (error) {
        console.error('Error saving attendance:', error);
        showNotification('Error saving attendance', 'error');
    }

    // Local fallback update so Class Management reflects the latest marking
    const total = attendanceRecords.length || 1;
    const percent = ((presentCount / total) * 100).toFixed(2);
    if (markedClassId) {
        appState.attendanceSnapshots[markedClassId] = attendanceRecords.map(r => ({
        userId: r.studentId,
        attendancePercentage: r.status === 'present' ? 100 : 0
        }));
        const cls = appState.classes.find(c => c._id === markedClassId || c.className === markedClassId);
        if (cls) {
            cls.attendancePercentage = percent;
        }
    }
    displayClasses(appState.classes);
    setupCharts();

    showLoading(false);
}

// ==================== POPULATE CLASS SELECTS ====================

function populateClassSelects() {
    const selects = [
        document.getElementById('classFilter'),
        document.getElementById('formClassId'),
        document.getElementById('attendanceClassSelect'),
        document.getElementById('reportClassSelect')
    ];

    selects.forEach(select => {
        if (!select) return;
        const currentValue = select.value;

        // Clear and rebuild options
        const isFilter = select.id === 'classFilter';
        select.innerHTML = isFilter ? '<option value=\"\">All Classes</option>' : '<option value=\"\">Select Class</option>';
        
        appState.classes.forEach(cls => {
            const option = document.createElement('option');
            option.value = cls._id; // _id is className for sheet fallback
            option.textContent = cls.className;
            select.appendChild(option);
        });

        select.value = currentValue;
    });
}

// ==================== CHARTS ====================

function setupCharts() {
    destructureCharts();
    setupClassAttendanceChart();
    setupTrendChart();
}

function destructureCharts() {
    Object.values(appState.charts).forEach(chart => {
        if (chart && typeof chart.destroy === 'function') {
            chart.destroy();
        }
    });
    appState.charts = {};
}

function setupClassAttendanceChart() {
    const ctx = document.getElementById('classAttendanceChart');
    if (!ctx) return;

    const labels = appState.classes.map(c => c.className);
    const data = appState.classes.map(c => parseFloat(c.attendancePercentage || 0));

    if (labels.length === 0) return;

    appState.charts.classAttendance = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: ['#667eea', '#764ba2', '#f093fb', '#f5576c', '#4facfe', '#00f2fe'],
                borderColor: '#ffffff',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

function setupTrendChart() {
    const ctx = document.getElementById('attendanceTrendChart');
    if (!ctx) return;

    const trend = appState.stats.weeklyTrend || [];
    const days = trend.length
        ? trend.map(t => new Date(t.date).toLocaleDateString('en-IN', { weekday: 'short' }))
        : ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
    const data = trend.length
        ? trend.map(t => parseFloat(t.percentage))
        : [85, 88, 82, 90, 87];

    appState.charts.trend = new Chart(ctx, {
        type: 'line',
        data: {
            labels: days,
            datasets: [{
                label: 'Attendance %',
                data: data,
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                tension: 0.4,
                fill: true,
                pointBackgroundColor: '#667eea',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            },
            plugins: {
                legend: {
                    display: true
                }
            }
        }
    });
}

// ==================== MODAL HANDLING ====================

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
    }
}

function setupModalHandlers() {
    // Close modals when clicking outside
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    });

    // Close buttons
    document.querySelectorAll('.modal-close').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const modal = e.target.closest('.modal');
            if (modal) {
                modal.classList.remove('active');
            }
        });
    });
}

// ==================== GLOBAL EVENT LISTENERS ====================

function setupEventListeners() {
    // Student Management
    document.getElementById('addStudentBtn')?.addEventListener('click', openAddStudentModal);
    document.getElementById('studentForm')?.addEventListener('submit', handleStudentFormSubmit);
    document.getElementById('studentSearch')?.addEventListener('input', handleStudentSearch);
    document.getElementById('classFilter')?.addEventListener('change', handleClassFilter);
    ['formStudentName', 'formGuardianName', 'formPhone', 'formClassId'].forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            const evt = id === 'formClassId' ? 'change' : 'input';
            el.addEventListener(evt, () => el.classList.remove('invalid'));
        }
    });

    // Class Management
    document.getElementById('addClassBtn')?.addEventListener('click', openAddClassModal);
    document.getElementById('classForm')?.addEventListener('submit', handleClassFormSubmit);

    // Attendance
    document.getElementById('loadAttendanceBtn')?.addEventListener('click', loadAttendanceStudents);
    document.getElementById('markAllPresentBtn')?.addEventListener('click', () => markAllAttendance('present'));
    document.getElementById('markAllAbsentBtn')?.addEventListener('click', () => markAllAttendance('absent'));
    document.getElementById('submitAttendanceBtn')?.addEventListener('click', submitAttendance);

    // Settings
    document.getElementById('saveSettingsBtn')?.addEventListener('click', saveSettings);

    // Logout
    document.getElementById('logoutBtn')?.addEventListener('click', logout);
}

// ==================== UTILITY FUNCTIONS ====================

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    
    const bgColor = {
        'success': '#10b981',
        'error': '#ef4444',
        'warning': '#f59e0b',
        'info': '#3b82f6'
    }[type] || '#3b82f6';

    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        background: ${bgColor};
        color: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        font-weight: 500;
        max-width: 400px;
        animation: slideInRight 0.3s ease-out;
    `;

    notification.textContent = message;
    document.body.appendChild(notification);

    // Auto remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease-out';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

function showLoading(show) {
    appState.loading = show;
    // Create or update loading spinner
    let spinner = document.getElementById('loadingSpinner');
    if (show && !spinner) {
        spinner = document.createElement('div');
        spinner.id = 'loadingSpinner';
        spinner.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 9999;
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        `;
        spinner.innerHTML = `
            <div style="text-align: center;">
                <div style="width: 40px; height: 40px; border: 4px solid #e5e7eb; border-top: 4px solid #667eea; border-radius: 50%; margin: 0 auto 1rem; animation: spin 1s linear infinite;"></div>
                <p style="color: #666; margin: 0;">Loading...</p>
            </div>
        `;
        document.body.appendChild(spinner);
    } else if (!show && spinner) {
        spinner.remove();
    }
}

function saveSettings() {
    const threshold = document.getElementById('thresholdInput')?.value;
    
    if (!threshold) {
        showNotification('Please enter a threshold value', 'error');
        return;
    }

    const thresholdNum = parseInt(threshold);
    if (isNaN(thresholdNum) || thresholdNum < 0 || thresholdNum > 100) {
        showNotification('Threshold must be a number between 0 and 100', 'error');
        return;
    }

    appState.threshold = thresholdNum;
    localStorage.setItem('attendanceThreshold', thresholdNum);
    showNotification('Settings saved successfully', 'success');
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.clear();
        window.location.href = 'index.html';
    }
}

// ==================== STYLES FOR ANIMATIONS ====================

// Create and inject animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
        }
        to {
            opacity: 1;
        }
    }

    .section {
        animation: fadeIn 0.3s ease-out;
    }

    .notification {
        font-size: 0.95rem;
    }
`;

document.head.appendChild(style);
