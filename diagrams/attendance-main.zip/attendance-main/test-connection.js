const mongoose = require('mongoose');

const dbURI = process.env.MONGODB_URI || process.env.MONGO_URI || process.env.DB_URI || 'mongodb://127.0.0.1:27017/attendance';
const dbName = process.env.MONGODB_DB || process.env.DB_NAME || 'attendance';


function maskUri(uri) {
    return uri.replace(/\/\/([^:@]+):([^@]+)@/, '//***:***@');
}

console.log('Testing MongoDB connection...\n');
console.log('Connection String:', maskUri(dbURI), '\n');

const startTime = Date.now();

mongoose.connect(dbURI, {
    dbName,
    serverSelectionTimeoutMS: 10000,
    connectTimeoutMS: 10000,
    socketTimeoutMS: 10000
}).then(() => {
    const elapsed = Date.now() - startTime;
    console.log(`MongoDB connected successfully in ${elapsed}ms`);
    console.log('Database:', mongoose.connection.db.databaseName);
    console.log('Connection State:', mongoose.connection.readyState, '(1 = Connected)');
    mongoose.connection.close();
    process.exit(0);
}).catch(err => {
    const elapsed = Date.now() - startTime;
    console.error(`Connection failed after ${elapsed}ms`);
    console.error('Error:', err.message);
    console.error('\nTroubleshooting Tips:');
    console.error('1. Check if your IP is whitelisted in MongoDB Atlas');
    console.error('2. Verify MONGODB_URI is correct and password is URL-encoded');
    console.error('3. Check if MongoDB Atlas account/cluster is active');
    process.exit(1);
});
