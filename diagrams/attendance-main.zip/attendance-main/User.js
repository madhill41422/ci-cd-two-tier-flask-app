const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    userId: { type: String, required: true, unique: true, index: true },
    studentId: { type: String, unique: true, sparse: true, index: true },
    password: { type: String, required: true },
    role: { type: String, required: true, enum: ['student', 'admin'], index: true }, // 'student' or 'admin'
    name: { type: String, default: '' }, // Full name for convenience
    firstName: { type: String, default: '' },
    lastName: { type: String, default: '' },
    email: { type: String, default: '' },
    phone: { type: String, default: '' },
    classId: { type: mongoose.Schema.Types.ObjectId, ref: 'Class', default: null }, // For students
    
    guardianName: { type: String, default: '' },
    // Parent/Guardian Contact Information (Optional - legacy)
    motherName: { type: String, default: '' },
    motherEmail: { type: String, default: '' },
    motherMobile: { type: String, default: '' },
    fatherName: { type: String, default: '' },
    fatherEmail: { type: String, default: '' },
    fatherMobile: { type: String, default: '' },

    attendance: { type: Array, default: [] },
    
    createdAt: { type: Date, default: Date.now, index: true }
}, { strict: false });

module.exports = mongoose.model('User', userSchema);
