require('dotenv').config();
const mongoose = require('mongoose');

// ── Pull URI from environment ──────────────────────────────────
const rawMongoUri =
    process.env.MONGODB_URI ||
    process.env.MONGO_URI   ||
    process.env.DB_URI;

// If no URI at all — crash immediately with a clear message
if (!rawMongoUri) {
    console.error('');
    console.error('❌ MONGODB_URI is not set!');
    console.error('   Create a .env file in your project root containing:');
    console.error('');
    console.error('   MONGODB_URI=mongodb+srv://bioplussciencepvtltd_db_user:bhavya12300@attendancecluster.mtdv7mn.mongodb.net/attendances?retryWrites=true&w=majority&appName=AttendanceCluster');
    console.error('');
    console.error('   Then run: npm install dotenv');
    console.error('   And make sure require("dotenv").config() is the FIRST line of index.js');
    console.error('');
    process.exit(1);
}

const dbName = process.env.MONGODB_DB || process.env.DB_NAME || 'attendances';

// ── Encode special characters in password (e.g. * @ # $) ──────
function encodeCredentialPart(value = '') {
    try {
        return encodeURIComponent(decodeURIComponent(value));
    } catch (_) {
        return encodeURIComponent(value);
    }
}

function normalizeMongoUri(uri) {
    if (!uri || typeof uri !== 'string') return '';
    const trimmed = uri.trim();

    const match = trimmed.match(/^(mongodb(?:\+srv)?:\/\/)([^@\/\s]+)@(.+)$/i);
    if (!match) return trimmed;

    const [, prefix, credential, suffix] = match;
    const sepIndex = credential.indexOf(':');
    if (sepIndex < 0) return trimmed;

    const username = credential.slice(0, sepIndex);
    const password = credential.slice(sepIndex + 1);
    if (!password) return trimmed;

    return `${prefix}${username}:${encodeCredentialPart(password)}@${suffix}`;
}

const dbURI = normalizeMongoUri(rawMongoUri);

console.log('[db] Using URI host:', dbURI.replace(/:[^:@]+@/, ':****@')); // log URI safely (password hidden)

// ── Connection event listeners ─────────────────────────────────
let hasConnectedOnce = false;

mongoose.connection.on('connected', () => {
    hasConnectedOnce = true;
    const actualDb = mongoose.connection?.db?.databaseName || dbName;
    console.log(`✅ [db] MongoDB connected (db: ${actualDb})`);
});

mongoose.connection.on('reconnected', () => {
    console.log('✅ [db] MongoDB reconnected');
});

mongoose.connection.on('error', (err) => {
    console.error('❌ [db] MongoDB error:', err.message);
    if (err.message.includes('bad auth') || err.message.includes('Authentication failed')) {
        console.error('   → Wrong username or password in your MONGODB_URI');
        console.error('   → Check your .env file');
    }
    if (err.message.includes('ENOTFOUND') || err.message.includes('ECONNREFUSED')) {
        console.error('   → Cannot reach MongoDB server');
        console.error('   → Check your internet connection');
        console.error('   → Check IP whitelist in MongoDB Atlas → Network Access');
    }
});

mongoose.connection.on('disconnected', () => {
    if (!hasConnectedOnce) {
        console.warn('[db] Waiting for MongoDB connection...');
        return;
    }
    console.warn('⚠️  [db] MongoDB disconnected');
});

// ── Connect function ───────────────────────────────────────────
let connectInFlight = null;

const connectDB = async () => {
    if (mongoose.connection.readyState === 1) {
        return mongoose.connection;
    }

    if (connectInFlight) {
        return connectInFlight;
    }

    mongoose.set('bufferCommands', false);

    connectInFlight = mongoose.connect(dbURI, {
        dbName,
        serverSelectionTimeoutMS: 30000,
        socketTimeoutMS:          45000,
        connectTimeoutMS:         30000,
    })
        .then(() => mongoose.connection)
        .catch((err) => {
            console.error('❌ [db] Connection failed:', err.message);
            if (err.message.includes('bad auth') || err.message.includes('Authentication failed')) {
                console.error('   FIX: Check username and password in your .env MONGODB_URI');
                console.error('   FIX: Special characters like * must be encoded — * becomes %2A');
            } else if (err.message.includes('ENOTFOUND')) {
                console.error('   FIX: Check your Atlas cluster hostname in the URI');
            } else {
                console.error('   FIX: Go to MongoDB Atlas → Network Access → Add your IP');
            }
            // Retry after 5 seconds
            setTimeout(() => { connectDB().catch(() => {}); }, 5000);
            return null;
        })
        .finally(() => {
            connectInFlight = null;
        });

    return connectInFlight;
};

module.exports = connectDB;