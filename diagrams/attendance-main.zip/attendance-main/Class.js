const mongoose = require('mongoose');

const classSchema = new mongoose.Schema({
    className: { type: String, required: true, index: true },
    section: { type: String, default: '', index: true },
    semester: { type: String, default: '' },
    totalStudents: { type: Number, default: 0 },
    createdAt: { type: Date, default: Date.now, index: true },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
});

// Enforce: section must be unique within a class (case-insensitive)
classSchema.index({ className: 1, section: 1 }, { unique: true, collation: { locale: 'en', strength: 2 } });

module.exports = mongoose.model('Class', classSchema);
