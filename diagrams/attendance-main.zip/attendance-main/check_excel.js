const XLSX = require('xlsx');
const { DEFAULT_EXCEL_PATH } = require('./excelImport');

// Simple helper to inspect the Excel file structure
const filePath = DEFAULT_EXCEL_PATH;
console.log(`Reading file from: ${filePath}`);

try {
    const workbook = XLSX.readFile(filePath);
    console.log('\nSheet names:', workbook.SheetNames);

    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const data = XLSX.utils.sheet_to_json(worksheet);

    console.log(`\nFound ${data.length} rows in sheet "${sheetName}"`);
    console.log('\nColumn headers:');
    if (data.length > 0) {
        console.log(Object.keys(data[0]));
    }

    console.log('\nFirst 3 records:');
    console.log(JSON.stringify(data.slice(0, 3), null, 2));
} catch (error) {
    console.error('Error reading Excel file:', error.message);
}
