let selectedRole = null;

// ==================== LOGIN PAGE FUNCTIONALITY ====================

// Role Selection Logic
document.getElementById('selectStudent')?.addEventListener('click', function() {
    selectedRole = 'student';
    showLoginForm('Student Login');
});

document.getElementById('selectAdmin')?.addEventListener('click', function() {
    selectedRole = 'admin';
    showLoginForm('Administrator Login');
});

// Back Button Logic
document.getElementById('backBtn')?.addEventListener('click', function(e) {
    e.preventDefault();
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('roleSelection').style.display = 'block';
    document.getElementById('userId').value = '';
    document.getElementById('password').value = '';
    selectedRole = null;
});

// Show Login Form
function showLoginForm(title) {
    document.getElementById('roleSelection').style.display = 'none';
    document.getElementById('loginForm').style.display = 'block';
    document.getElementById('formTitle').innerText = title;
    document.getElementById('userId').focus();
}

// Login Form Submission with Role-Based Redirect
document.getElementById('loginFormElement')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const userId = document.getElementById('userId').value;
    const password = document.getElementById('password').value;
    const loginBtn = document.getElementById('loginBtn');

    if (!userId || !password) {
        alert("Please fill in all fields");
        return;
    }

    // Show loading state
    loginBtn.disabled = true;
    const originalText = loginBtn.innerHTML;
    loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Signing In...';

    try {
        const response = await fetch('http://localhost:3000/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId, password, role: selectedRole })
        });

        const data = await response.json();

        if (data.success) {
            // Store user info
            localStorage.setItem('userRole', selectedRole);
            localStorage.setItem('userId', userId);
            localStorage.setItem('userName', data.user?.name || userId);
            localStorage.setItem('classId', data.user?.classId || '');
            localStorage.setItem('className', data.user?.className || '');

            // Role-Based Redirect
            if (selectedRole === 'admin') {
                window.location.href = "admin-dashboard.html";
            } else {
                window.location.href = "student-dashboard.html";
            }
        } else {
            alert("Login Failed: Incorrect Password for " + selectedRole);
            loginBtn.disabled= false;
            loginBtn.innerHTML = originalText;
        }
    } catch (error) {
        alert("Connection Error: Is your backend running (npm start)?");
        loginBtn.disabled = false;
        loginBtn.innerHTML = originalText;
    }
});

// ==================== LOGOUT FUNCTIONALITY ====================
function logout() {
    localStorage.clear();
    window.location.href = 'index.html';
}