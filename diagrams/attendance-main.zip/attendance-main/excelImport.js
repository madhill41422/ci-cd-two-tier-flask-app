const bcrypt = require('bcrypt');
const fs = require('fs');
const path = require('path');
const XLSX = require('xlsx');
const User = require('./User');
const Class = require('./Class');
const { formatStudentId, fetchMaxStudentNumber } = require('./studentId');

// Default Excel path (can be overridden with EXCEL_PATH env var or passed to the function)
function resolveDefaultExcelPath() {
    const homeDir = process.env.USERPROFILE || process.env.HOME || __dirname;
    const candidates = [
        process.env.EXCEL_PATH,
        path.join(__dirname, 'students_data.xlsx'),
        path.join(homeDir, 'Documents', 'students_data.xlsx'),
        path.join(homeDir, 'Documents', 'student_data.xlsx') // legacy
    ].filter(Boolean);

    for (const candidate of candidates) {
        if (fs.existsSync(candidate)) {
            return candidate;
        }
    }
    // fallback to project-local even if it does not yet exist
    return path.join(__dirname, 'students_data.xlsx');
}

const DEFAULT_EXCEL_PATH = resolveDefaultExcelPath();

function trimHeaders(row = {}) {
    const cleaned = {};
    Object.entries(row).forEach(([key, value]) => {
        if (!key) return;
        const trimmedKey = key.trim();
        if (!trimmedKey) return;
        cleaned[trimmedKey] = typeof value === 'string' ? value.trim() : value;
    });
    return cleaned;
}

/**
 * Ensure the standard twelve classes (Class 1 - Class 12) exist.
 * Returns the list of classes containing those names.
 */
async function ensureBaseClasses() {
    const requiredNames = Array.from({ length: 12 }, (_, idx) => `Class ${idx + 1}`);
    const existing = await Class.find({ className: { $in: requiredNames } }).lean();

    const existingNames = new Set(existing.map((c) => c.className));
    const missing = requiredNames.filter((name) => !existingNames.has(name));

    if (missing.length > 0) {
        const payload = missing.map((name) => {
            const num = parseInt(name.replace(/\D+/g, ''), 10);
            return {
                className: name,
                section: `Section ${String.fromCharCode(65 + Math.floor((num - 1) / 4))}`, // A, B, C
                semester: num <= 6 ? 'Semester 1' : 'Semester 2'
            };
        });
        await Class.User.create(payload);
    }

    // Return fresh list with the required names
    return Class.find({ className: { $in: requiredNames } }).lean();
}

/**
 * Import students from an Excel file into MongoDB.
 * @param {string} [filePath] - Optional custom path; falls back to DEFAULT_EXCEL_PATH
 * @returns {Promise<{success:boolean,message:string,inserted:number,skipped:number,total:number,errors:string[]}>}
 */
async function importStudentsFromExcel(filePath) {
    const excelPath = filePath ? path.resolve(filePath) : DEFAULT_EXCEL_PATH;

    if (!fs.existsSync(excelPath)) {
        return {
            success: false,
            message: `Excel file not found at: ${excelPath}`,
            inserted: 0,
            skipped: 0,
            total: 0,
            errors: [`Missing file: ${excelPath}`]
        };
    }

    const workbook = XLSX.readFile(excelPath);
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json(worksheet);

    if (!rows || rows.length === 0) {
        return {
            success: false,
            message: 'Excel file is empty',
            inserted: 0,
            skipped: 0,
            total: 0,
            errors: ['No rows found in Excel file']
        };
    }

    let inserted = 0;
    let skipped = 0;
    const errors = [];
    let nextSeq = (await fetchMaxStudentNumber()) + 1;

    for (let i = 0; i < rows.length; i++) {
        const cleanedRow = trimHeaders(rows[i]);
        if (Object.keys(cleanedRow).length === 0) {
            skipped++;
            continue;
        }

        const excelId = cleanedRow.ID || cleanedRow.Id || cleanedRow.id || '';
        const generatedId = formatStudentId(nextSeq++);
        const userIdStr = (excelId && excelId.toString().trim()) || generatedId;

        const duplicate = await User.findOne({ $or: [{ userId: userIdStr }, { studentId: userIdStr }] }).lean();
        if (duplicate) {
            skipped++;
            continue;
        }

        const doc = {
            ...cleanedRow,
            userId: userIdStr,
            studentId: userIdStr,
            name: cleanedRow.Name || cleanedRow.name || cleanedRow['Full Name'] || '',
            email: cleanedRow.Email || cleanedRow.email || '',
            phone: cleanedRow.Phone || cleanedRow.phone || '',
            password: 'studentPassword123',
            role: 'student'
        };

        try {
            await User.create(doc);
            inserted++;
        } catch (err) {
            skipped++;
            errors.push(`Row ${i + 2}: ${err.message}`);
        }
    }

    return {
        success: true,
        message: `Imported ${inserted} student(s). Skipped ${skipped}.`,
        inserted,
        skipped,
        total: rows.length,
        errors
    };
}

/**
 * Helper to run during startup: if there are no students, import from Excel.
 */
async function bootstrapFromExcelIfEmpty() {
    const studentCount = await User.countDocuments({ role: 'student' });
    if (studentCount > 0) {
        return { skipped: true, message: 'Students already present; bootstrap skipped' };
    }

    return importStudentsFromExcel();
}

module.exports = {
    ensureBaseClasses,
    importStudentsFromExcel,
    bootstrapFromExcelIfEmpty,
    DEFAULT_EXCEL_PATH
};
