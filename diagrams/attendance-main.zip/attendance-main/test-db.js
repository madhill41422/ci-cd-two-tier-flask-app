require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('./db');
const User = require('./User');
const Class = require('./Class');
const Attendance = require('./Attendance');

async function testDB() {
    console.log('🔄 Connecting to MongoDB...\n');
    await connectDB();

    // Wait for connection
    await new Promise(r => setTimeout(r, 3000));

    if (mongoose.connection.readyState !== 1) {
        console.log('❌ MongoDB is NOT connected. Check your URI in db.js');
        process.exit(1);
    }

    console.log('✅ MongoDB is connected!\n');
    console.log('📦 Database name:', mongoose.connection.db.databaseName);
    console.log('🌐 Host:', mongoose.connection.host);
    console.log('');

    // Count documents in each collection
    const userCount       = await User.countDocuments();
    const studentCount    = await User.countDocuments({ role: 'student' });
    const adminCount      = await User.countDocuments({ role: 'admin' });
    const classCount      = await Class.countDocuments();
    const attendanceCount = await Attendance.countDocuments();

    console.log('📊 Collection counts:');
    console.log(`   Users total  : ${userCount}`);
    console.log(`   Students     : ${studentCount}`);
    console.log(`   Admins       : ${adminCount}`);
    console.log(`   Classes      : ${classCount}`);
    console.log(`   Attendance   : ${attendanceCount}`);
    console.log('');

    // Check if admin exists
    const admin = await User.findOne({ role: 'admin' }).select('userId email password').lean();
    if (admin) {
        console.log('✅ Admin account found:');
        console.log(`   userId       : ${admin.userId}`);
        console.log(`   email        : ${admin.email}`);
        console.log(`   passwordType : ${admin.password?.startsWith('$2') ? 'bcrypt hash' : 'plain text'}`);
    } else {
        console.log('❌ No admin account found! Run: http://localhost:3000/setup');
    }
    console.log('');

    // Check if students exist
    if (studentCount === 0) {
        console.log('⚠️  No students found. Run: http://localhost:3000/setup');
    } else {
        const sample = await User.findOne({ role: 'student' })
            .select('userId name firstName password')
            .lean();
        console.log('✅ Sample student:');
        console.log(`   userId       : ${sample.userId}`);
        console.log(`   name         : ${sample.name || sample.firstName}`);
        console.log(`   passwordType : ${sample.password?.startsWith('$2') ? 'bcrypt hash' : 'plain text'}`);
    }

    console.log('\n✅ All checks done. MongoDB is working correctly!');
    process.exit(0);
}

testDB().catch(err => {
    console.error('❌ Test failed:', err.message);
    process.exit(1);
});