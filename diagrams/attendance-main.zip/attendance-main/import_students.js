const mongoose = require('mongoose');
const connectDB = require('./db');
const { importStudentsFromExcel, DEFAULT_EXCEL_PATH } = require('./excelImport');

async function runImport() {
    try {
        await connectDB();
        console.log(`Reading Excel data from: ${DEFAULT_EXCEL_PATH}`);
        const result = await importStudentsFromExcel();
        console.log(result.message);

        if (result.errors && result.errors.length > 0) {
            console.log('Errors:', result.errors.slice(0, 10));
        }
    } catch (error) {
        console.error('Import failed:', error.message);
    } finally {
        await mongoose.connection.close();
    }
}

runImport();
