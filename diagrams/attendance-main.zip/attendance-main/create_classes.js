const mongoose = require('mongoose');
const Class = require('./Class');
const connectDB = require('./db');

const colors = {
    reset: '\x1b[0m',
    green: '\x1b[32m',
    red: '\x1b[31m',
    blue: '\x1b[36m'
};

const log = {
    success: (msg) => console.log(`${colors.green}✅ ${msg}${colors.reset}`),
    info: (msg) => console.log(`${colors.blue}ℹ️ ${msg}${colors.reset}`)
};

async function createClasses() {
    try {
        log.info('Connecting to MongoDB...');
        await connectDB();
        log.success('Connected to MongoDB');

        // Check if classes already exist
        const existingClasses = await Class.find({});
        if (existingClasses.length > 0) {
            log.success(`✨ ${existingClasses.length} classes already exist in database`);
            await mongoose.connection.close();
            return;
        }

        // Create 12 classes matching the data (Class 1-12 become Class A-L)
        const classNames = ['Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5', 'Class 6', 
                           'Class 7', 'Class 8', 'Class 9', 'Class 10', 'Class 11', 'Class 12'];
        
        const classes = classNames.map((name, index) => ({
            className: name,
            section: `Section ${String.fromCharCode(65 + Math.floor(index / 4))}`, // A, B, C sections
            semester: index < 6 ? 'Semester 1' : 'Semester 2'
        }));

        const createdClasses = await Class.insertMany(classes);
        log.success(`Created ${createdClasses.length} classes:`);
        
        createdClasses.forEach((cls, index) => {
            console.log(`  ${index + 1}. ${cls.className} - ${cls.section} - ${cls.semester}`);
        });

        await mongoose.connection.close();
        log.success('Database connection closed');

    } catch (error) {
        console.error('❌ Error:', error.message);
    }
}

createClasses();
